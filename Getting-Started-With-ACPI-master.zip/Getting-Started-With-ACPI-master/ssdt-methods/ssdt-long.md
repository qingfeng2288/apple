# SSDTs: The long way

Well sadly some things are not handled by SSDTTime, well have no fear as making SSDTs is super easy. The basic process:

* Dump DSDT(the one SSDTTime did for us will work)
* Decompile DSDT
* Make SSDTs based off of it(You'll need either MaciASL or a text editor for this)
* Compile SSDTs

Now continue forth and master the ways of ACPI!
