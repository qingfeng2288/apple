
# Fixing Embedded Controller (Desktop)

## You'll want to go to [SSDT-EC under the Universal tab](/Universal/ec-fix.md) for the new SSDT-EC page
