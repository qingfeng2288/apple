# Fixing Backlight: Prebuilt

By far the easiest method, all you need to do is download the following file:

* [SSDT-PNLF.aml](https://github.com/dortania/Getting-Started-With-ACPI/blob/master/extra-files/compiled/SSDT-PNLF.aml)

Main things to note with this method:

* Assumes GPU pathing, works great for 99% of devices but if you're having issues controlling backlight this may be something to look at
* Doesn't really teach you anything
  * For most, this doesn't matter. But to some knowing what makes your hackintosh tick is part of the journey
