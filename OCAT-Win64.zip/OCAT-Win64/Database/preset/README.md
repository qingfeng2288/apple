# OCAT Quirks Presets
Templates in `.txt` format for **ACPI**, **Booter**, **Kernel** and **UEFI** used in [OpenCore Auxiliary Tools](https://github.com/ic005k/QtOpenCoreConfig) `Quirks` dropdown menus. Mainly used for backup reasons. They are already included in OCAT. But the newest versions will always be hosted here.

## Manual Installation
Copy files to: `/OCAuxiliaryTools.app/Contents/MacOS/Database/preset`

